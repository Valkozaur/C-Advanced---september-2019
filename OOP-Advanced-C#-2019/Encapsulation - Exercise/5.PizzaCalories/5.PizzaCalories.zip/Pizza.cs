﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _5.PizzaCalories
{
    public class Pizza
    {
        private const string NameLenghtErrorMessage = "Pizza name should be between 1 and 15 symbols.";

        private string name;
        private Dough dough;
        private List<Toping> topings;

        public Pizza(string name, Dough dough)
        {
            this.name = name;
            this.dough = dough;
            this.topings = new List<Toping>();
        }

        public string Name 
        {
            get => this.name;
            set
            {
                if (string.IsNullOrEmpty(value) || value.Length > 15)
                {
                    throw new ArgumentException(NameLenghtErrorMessage);
                }
            }
        }

        public int NumberOfTopings => this.topings.Count;
        public double TotalCalories => this.dough.Calories + this.topings.Sum(x => x.Calories);

        public int ToppingCount => this.topings.Count;

        public void AddToping(Toping topping)
        {
            if (ToppingCount == 10)
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }

            this.topings.Add(topping);
        }
    }
}
