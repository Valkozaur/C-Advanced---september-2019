﻿namespace P03.WildFarm.Models.Foods
{
    public abstract class Food
    {    
        public int Quantity { get; set; }
    }
}
