﻿namespace P03.WildFarm.Models.Foods
{
    public class Meat : Food
    {
    }
}
