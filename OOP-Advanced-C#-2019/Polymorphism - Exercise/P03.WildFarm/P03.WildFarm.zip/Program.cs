﻿namespace P03.WildFarm
{
    using System;
    using System.Collections.Generic;
    using Models.Foods;
    using WildFarm.Models;
    using Models.Animals.Mammals;
    using Models.Animals.Birds;
    using Models.Animals.Mammals.Felines;

    public class Program
    {
        public static void Main()
        {
            var animals = new List<Animal>();

            while (true)
            {
                var input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }

                Animal currentAnimal = GetAnimal(input);
                animals.Add(currentAnimal);

                var foodInput = Console.ReadLine().Split();
                var foodName = foodInput[0];
                var quantity = int.Parse(foodInput[1]);

                Console.WriteLine(currentAnimal.ProduceSound);
                try
                {
                    currentAnimal.Eat(foodName, quantity);
                }
                catch (ArgumentException ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }

            foreach (var animal in animals)
            {
                Console.WriteLine(animal);
            }
        }

        private static Animal GetAnimal(string input)
        {
            Animal currentAnimal = null;

            var animalInfo = input
                                .Split();
            var animalType = animalInfo[0];
            var name = animalInfo[1];
            var weight = double.Parse(animalInfo[2]);

            if (animalType == "Owl" || animalType == "Hen")
            {
                var wingSize = double.Parse(animalInfo[3]);
                if (animalType == "Owl")
                {
                    currentAnimal = new Owl(name, weight, wingSize);
                }
                else
                {
                    currentAnimal = new Hen(name, weight, wingSize);
                }
            }
            else if (animalType == "Tiger" || animalType == "Cat")
            {
                var livingRegion = animalInfo[3];
                var breed = animalInfo[4];

                if (animalType == "Tiger")
                {
                    currentAnimal = new Tiger(name, weight, livingRegion, breed);
                }
                else
                {
                    currentAnimal = new Cat(name, weight, livingRegion, breed);
                }
            }
            else if (animalType == "Mouse" || animalType == "Dog")
            {
                var livingRegion = animalInfo[3];

                if (animalType == "Mouse")
                {
                    currentAnimal = new Mouse(name, weight, livingRegion);
                }
                else
                {
                    currentAnimal = new Dog(name, weight, livingRegion);
                }
            }

            return currentAnimal;
        }
    }
}
