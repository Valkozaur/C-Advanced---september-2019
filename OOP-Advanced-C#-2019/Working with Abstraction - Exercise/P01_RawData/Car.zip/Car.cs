﻿using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;

namespace P01_RawData
{
    public class Car
    {
        

        public Car(string model, int engineSpeed, int enginePower, int cargoWeight, string cargoType, List<string> tiresSpecifications)
        {
            this.Model = model;
            this.EngineSpeed = engineSpeed;
            this.EnginePower = enginePower;
            this.CargoWeight = cargoWeight;
            this.CargoType = cargoType;
            this.Tires = new List<Tire>();
            this.TiresInput(tiresSpecifications);
        }

        public List<Tire> Tires { get; set; }
        public string Model { get; set; }

        public int EngineSpeed { get; set; }


        public int EnginePower { get; set; }


        public int CargoWeight { get; set; }

        public string CargoType { get; set; }

        private void TiresInput(List<string> tiresSpecification)
        {
            for (var i = 1; i < tiresSpecification.Count; i+=2)
            {
                var tirePressure = double.Parse(tiresSpecification[i - 1]);
                var tireAge = int.Parse(tiresSpecification[i]);

                var tire = new Tire(tirePressure, tireAge);
                this.Tires.Add(tire);
            }
        }
    }
}
