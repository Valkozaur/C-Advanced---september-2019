﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P01_RawData
{

    public class RawData
    {
        static void Main(string[] args)
        {
            var cars = new List<Car>();

            var lines = int.Parse(Console.ReadLine());

            for (var i = 0; i < lines; i++)
            {
                var parameters = Console.ReadLine()
                    .Split(new[] { ' ' }, 6, StringSplitOptions.RemoveEmptyEntries);

                var model = parameters[0];
                var engineSpeed = int.Parse(parameters[1]);
                var enginePower = int.Parse(parameters[2]);
                var cargoWeight = int.Parse(parameters[3]);
                var cargoType = parameters[4];

                var tiresSpecifications = parameters[5]
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToList();
                
                cars.Add(new Car(model, engineSpeed, enginePower, cargoWeight, cargoType, tiresSpecifications));
            }

            var command = Console.ReadLine();
            if (command == "fragile")
            {
                var fragile = cars
                    .Where(x => x.CargoType == "fragile" && x.Tires.Any(y => y.Pressure < 1))
                    .Select(x => x.Model)
                    .ToList();

                Console.WriteLine(string.Join(Environment.NewLine, fragile));
            }
            else
            {
                var flamable = cars
                    .Where(x => x.CargoType == "flamable" && x.EnginePower > 250)
                    .Select(x => x.Model)
                    .ToList();

                Console.WriteLine(string.Join(Environment.NewLine, flamable));
            }
        }
    }
}
