﻿namespace P04_Hospital
{
    public class Program
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.StartUp();
        }
    }
}
