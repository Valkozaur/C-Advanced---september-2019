﻿namespace RobotService.Models.Robots
{
    public class HouseholdRobot : Robot
    {
        public HouseholdRobot(string name, int energy, int happiness, int produceTime) 
            : base(name, energy, happiness, produceTime)
        {
        }
    }
}
