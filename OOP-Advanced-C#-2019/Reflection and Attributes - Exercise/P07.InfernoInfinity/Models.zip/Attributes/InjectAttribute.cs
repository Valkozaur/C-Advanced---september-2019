﻿namespace P07.InfernoInfinity.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field)]
    public class InjectAttribute : Attribute
    {
    }
}
