﻿namespace P07.InfernoInfinity.Attributes
{
    using System;
    [AttributeUsage(AttributeTargets.Property)]
    public class ModdifiableAttribute : Attribute
    {
    }
}
