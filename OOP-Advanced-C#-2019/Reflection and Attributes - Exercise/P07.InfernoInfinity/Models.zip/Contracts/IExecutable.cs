﻿namespace P07.InfernoInfinity.Contracts
{
    using System.Collections.Generic;

    public interface IExecutable
    {
        void Execute();
    }
}
