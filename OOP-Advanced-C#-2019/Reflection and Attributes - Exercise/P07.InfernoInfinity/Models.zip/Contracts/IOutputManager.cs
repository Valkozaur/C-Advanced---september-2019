﻿namespace P07.InfernoInfinity.Contracts
{
    public interface IOutputManager
    {
        void Print(string text);
    }
}
