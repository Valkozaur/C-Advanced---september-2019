﻿namespace P07.InfernoInfinity.Contracts
{
    public interface IInputManager
    {
        string ReadLine();
    }
}
