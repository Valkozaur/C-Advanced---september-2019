﻿namespace P04.Telephony
{
    interface IInternetBrowsable
    {
        string InternetBrowse(string website);
    }
}
