﻿namespace P08.CollectionHierarchy.Collections
{
    using P08.CollectionHierarchy.CollectionModels;

    public class AddRemoveCollection<T> : IAddRemoveCollection<T>
    {
    }
}
