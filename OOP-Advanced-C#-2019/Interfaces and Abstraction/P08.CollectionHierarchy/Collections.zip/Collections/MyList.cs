﻿namespace P08.CollectionHierarchy.Collections
{
    using CollectionModels;

    public class MyList<T> : IMyList<T>
    {
    }
}
