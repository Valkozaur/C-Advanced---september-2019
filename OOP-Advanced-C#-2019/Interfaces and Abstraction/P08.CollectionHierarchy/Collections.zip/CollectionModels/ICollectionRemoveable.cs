﻿namespace P08.CollectionHierarchy.CollectionModels
{
    public interface ICollectionRemoveable<T>
    {
        T Remove();
    }
}
