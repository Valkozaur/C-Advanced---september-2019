﻿namespace _4.BorderControl.Interfaces
{
    using System;

    public interface IBeing
    {
        string Name { get; set; }

        string BirthDate { get; set; }
    }
}
