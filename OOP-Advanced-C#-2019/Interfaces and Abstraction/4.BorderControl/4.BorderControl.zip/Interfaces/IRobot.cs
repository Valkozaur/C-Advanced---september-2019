﻿namespace _4.BorderControl
{
    interface IRobot
    {
        string Model { get; set; }
    }
}
