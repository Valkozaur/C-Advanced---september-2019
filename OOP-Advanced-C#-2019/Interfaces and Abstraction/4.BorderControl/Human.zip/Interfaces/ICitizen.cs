﻿namespace _4.BorderControl
{
    using System;

    public interface ICitizen
    {
        string Id { get; set; }
    }
}
