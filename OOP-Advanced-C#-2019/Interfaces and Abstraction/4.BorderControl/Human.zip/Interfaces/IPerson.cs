﻿namespace _4.BorderControl.Interfaces
{
    public interface IPerson
    {
        string Name { get; set; }

        int Age { get; set; }
    }
}
