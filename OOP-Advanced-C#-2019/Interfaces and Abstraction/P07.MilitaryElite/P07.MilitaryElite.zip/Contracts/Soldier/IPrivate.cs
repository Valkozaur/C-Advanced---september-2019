﻿namespace P07.MilitaryElite.Contracts.Soldiers.Privates
{
    public interface IPrivate
    {
        decimal Salary { get; }
    }
}
