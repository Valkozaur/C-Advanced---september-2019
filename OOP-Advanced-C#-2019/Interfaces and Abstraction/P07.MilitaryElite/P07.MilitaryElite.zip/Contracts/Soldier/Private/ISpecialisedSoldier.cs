﻿namespace P07.MilitaryElite.Contracts.Soldier.Private.SpecialisedSoldier
{
    using Soldiers.Privates;

    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
