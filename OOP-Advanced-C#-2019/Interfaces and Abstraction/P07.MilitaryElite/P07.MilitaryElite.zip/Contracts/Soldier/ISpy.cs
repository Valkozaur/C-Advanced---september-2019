﻿namespace P07.MilitaryElite.Contracts.Soldiers
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}
