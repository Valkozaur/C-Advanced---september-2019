﻿namespace P07.MilitaryElite.Contracts.Soldiers
{
    public interface ISoldier
    {
        string Id { get; }
        
        string FirstName { get; }

        string LastName { get; }
    }
}
