﻿namespace P03.Ferrari
{
    public abstract class Car
    {
        public string Brakes => "Brakes!";

        public string GasPedal => "Gas!";
    }
}
