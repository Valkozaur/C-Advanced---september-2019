﻿using System.Collections.Generic;
using System.Dynamic;

namespace _1._Generic_Box_of_String
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            var boxes = new List<Box<string>>();

            var numberOfInput = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfInput; i++)
            {
                var inputName = Console.ReadLine();
                var box = new Box<string>(inputName);
                boxes.Add(box);
            }

            foreach (var box in boxes)
            {
                Console.WriteLine(box);
            }
        }
    }
}
