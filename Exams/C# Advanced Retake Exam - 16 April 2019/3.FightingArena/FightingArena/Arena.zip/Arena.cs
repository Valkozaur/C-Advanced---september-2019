﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;

namespace FightingArena
{
    public class Arena
    {
        private List<Gladiator> gladiators;

        public string Name { get; set; }

        public int Count => gladiators.Count;

        public void AddGladiator(Gladiator gladiator)
        {
            gladiators.Add(gladiator);
        }

        public void Remove(string name)
        {
            var gladiatorToRemove = gladiators.FirstOrDefault(x => x.Name == name);
            gladiators.Remove(gladiatorToRemove);
        }

        public Gladiator GetGladiatorWithHighestStatPower() =>
            gladiators.FirstOrDefault(x => x.GetStatPower() == gladiators.Max(m => m.GetStatPower()));

        public Gladiator GetGladiatorWithHighestWeaponPower() =>
            gladiators.FirstOrDefault(x => x.GetWeaponPower() == gladiators.Max(m => m.GetWeaponPower()));

        public Gladiator GetGladiatorWithHighestTotalPower() =>
            gladiators.FirstOrDefault(x => x.GetTotalPower() == gladiators.Max(m => m.GetTotalPower()));

        public override string ToString()
        {
            return $"[{this.Name}] - [{this.Count}] gladiators are participating.";
        }
    }
}